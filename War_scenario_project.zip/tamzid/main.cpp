#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <GL/gl.h>
bool isDay = false;
float timeOfDay = 0.0f;

/////
void initGL();
void display();
void timer(int value);
void renderBuildings();
void midPointLine(float x1, float y1, float x2, float y2);

float tank1X = 0.0f;
float tank2X =  0.0f;
float soldier1X = 0.0f;
float soldier2X = 0.0f;
float soldierBulletSpeed = 0.5f;
int soldierBulletVisible = 0;

float soldier2BulletX[6], soldier2BulletY[6];
int soldier2Fire = 0;
int soldier2BulletVisible = 0;
float soldier2BulletSpeed = 0.5f;
float bullet1StartX, bullet1StartY;
float bullet2StartX, bullet2StartY;
float bulletTravelLimit = 5.0f;

float soldierBulletX[6], soldierBulletY[6];
int soldierFire = 0;

float bullet1X, bullet1Y;
int fire1 = 0;

//  2
float bullet2X, bullet2Y;
int fire2 = 0;

// Blast
int blast1 = 0, blast2 = 0;
int blastTime1 = 0, blastTime2 = 0;

float angle = 30.0;
float rad = 30.0 * 3.1416 / 180.0;
////// for plane
float planeX = -10.0f;   // start off-screen
int planeMoving = 0;      // 0 = stopped, 1 = moving
float planeSpeed = 0.2f;  // movement speed

// Bomb variables
float bombX = 0.0f;
float bombY = 0.0f;
int bombDropped = 0;
float bombSpeed = 0.1f;
int bombBlast = 0;
int bombBlastTime = 0;

bool bombShot = false;

float bombVX, bombVY;
float gravity = 0.02f;

float shiftX1 = -12.9f;
float shiftY1 = 0.08f;







void timer(int value)
{
    timeOfDay += 0.01f;

    if (planeMoving)
        planeX += planeSpeed;

    if (timeOfDay >= 1.0f)
    {
        isDay = !isDay;
        timeOfDay = 0.0f;
    }


    glutPostRedisplay();

    glutTimerFunc(100, timer, 0);
}

void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glMatrixMode(GL_PROJECTION);

    glLoadIdentity();

    gluOrtho2D(-10, 9.5, -5, 5);
    glMatrixMode(GL_MODELVIEW);
}

//void midPointLine(float x1, float y1, float x2, float y2);
void midPointLine(float x1, float y1, float x2, float y2)
{
    float dx = x2 - x1;
    float dy = y2 - y1;
    float d = dy - (dx / 2);

    float x = x1;
    float y = y1;

    glBegin(GL_POINTS);
    while (x <= x2)
    {
        glVertex2f(x, y);

        if (d < 0)
        {
            d = d + dy;
            x = x + 0.01f;
        }
        else
        {
            d = d + dy - dx;
            x = x + 0.01f;
            y = y + 0.01f;
        }
    }
    glEnd();
}

void drawCircle(float cx, float cy, float r)
{
    glBegin(GL_POLYGON);
    for(int i=0;i<360;i++){
        float a = i * 3.1416 / 180;
        glVertex2f(cx + r*cos(a), cy + r*sin(a));
    }
    glEnd();
}

void display()
{
    if (isDay) {
        glClearColor(0.5f, 0.8f, 1.0f, 1.0f);
    } else {
        glClearColor(0.0f, 0.0f, 0.2f, 1.0f);
    }
    glClear(GL_COLOR_BUFFER_BIT);


    renderBuildings();


    if (isDay) {
        // Sun code
        glColor3f(1.0f, 0.8f, 0.0f);
        glBegin(GL_POLYGON);
        float x_center = 6.1f, y_center = 2.46f;
        float radius = 0.3f;
        for (int angle = 0; angle <= 360; angle++) {
            float rad = angle * 3.1416f / 180;
            glVertex2f(x_center + radius * cos(rad), y_center + radius * sin(rad));
        }
        glEnd();
    } else {
        // Moon code
        glColor3f(1.0f, 1.0f, 0.8f);
        glBegin(GL_POLYGON);
        float x_center = 6.71f, y_center = 2.46f;
        float radius = 0.3f;
        for (int angle = 0; angle <= 360; angle++) {
            float rad = angle * 3.1416f / 180;
            glVertex2f(x_center + radius * cos(rad), y_center + radius * sin(rad));
        }
        glEnd();
    }


    glPushMatrix();
    glLoadIdentity();
    glTranslatef(soldier1X, 0.0f, 0.0f);
    glColor3f(0.0f, 0.0f, 0.0f);
    //////////////// right soldier //////////////////////////////////
    drawCircle(3.68, -1.98, 0.05);
    drawCircle(4.04, -1.98, 0.05);
    drawCircle(4.62, -2.27, 0.05);
    drawCircle(4.25, -2.28, 0.05);
    drawCircle(3.88, -2.28, 0.05);
    drawCircle(3.52, -2.27, 0.05);

glLineWidth(5.0f);
glBegin(GL_LINES);

        glVertex2f(4.04,-2.03); //k
        glVertex2f(4.15,-2.23);//L

        glVertex2f(4.04,-2.03);//K
        glVertex2f(4.01,-2.24);//M

        glVertex2f(3.69,-2.03);//N
        glVertex2f(3.79,-2.24);//O

        glVertex2f(3.69,-2.03);//N
        glVertex2f(3.65,-2.24);//P

        glVertex2f(4.62,-2.32);//Q
        glVertex2f(4.73,-2.55);//R

        glVertex2f(4.62,-2.32);//Q
        glVertex2f(4.58,-2.55);//S

        glVertex2f(4.25,-2.32);//T
        glVertex2f(4.35,-2.54);//U

        glVertex2f(4.25,-2.32);//T
        glVertex2f(4.21,-2.54);//V

        glVertex2f(3.88,-2.32);//W,,,,,,
        glVertex2f(3.99,-2.53);//Z,,,

        glVertex2f(3.88,-2.32);//W
        glVertex2f(3.84,-2.54);//A1

        glVertex2f(3.52,-2.32);//B1
        glVertex2f(3.63,-2.54);//C1

        glVertex2f(3.52,-2.32);//B1
        glVertex2f(3.47,-2.55);//D1

        glVertex2f(4.06,-2.06);//K1
        glVertex2f(3.91,-2.06);//L1

        glVertex2f(3.7,-2.07);//M1
        glVertex2f(3.51,-2.06);//N1

        glVertex2f(4.64,-2.37);//O1
        glVertex2f(4.47,-2.36);//P1

        glVertex2f(4.28,-2.36);//Q1
        glVertex2f(4.11,-2.36);//R1

        glVertex2f(3.91,-2.36);//S1
        glVertex2f(3.73,-2.36);//T1

        glVertex2f(3.55,-2.36);//U1
        glVertex2f(3.34,-2.35);//V1

    glEnd();
    glLineWidth(1.0f);

//////////////// Left soldier //////////////////////////////////
glPushMatrix();
glTranslatef(soldier2X, 0.0f, 0.0f);
glColor3f(0.0f, 0.0f, 0.0f);
float shiftX2 = -8.8f;   // move soldiers left
float shiftHandX2 = -8.61f;
drawCircle(3.68 + shiftX2, -1.98, 0.05);
drawCircle(4.04 + shiftX2, -1.98, 0.05);
drawCircle(4.62 + shiftX2, -2.27, 0.05);
drawCircle(4.25 + shiftX2, -2.28, 0.05);
drawCircle(3.88 + shiftX2, -2.28, 0.05);
drawCircle(3.52 + shiftX2, -2.27, 0.05);

glLineWidth(5.0f);
glBegin(GL_LINES);

glVertex2f(4.04 + shiftX2, -2.03);
glVertex2f(4.15 + shiftX2, -2.23);

glVertex2f(4.04 + shiftX2, -2.03);
glVertex2f(4.01 + shiftX2, -2.24);

glVertex2f(3.69 + shiftX2, -2.03);
glVertex2f(3.79 + shiftX2, -2.24);

glVertex2f(3.69 + shiftX2, -2.03);
glVertex2f(3.65 + shiftX2, -2.24);

glVertex2f(4.62 + shiftX2, -2.32);
glVertex2f(4.73 + shiftX2, -2.55);

glVertex2f(4.62 + shiftX2, -2.32);
glVertex2f(4.58 + shiftX2, -2.55);

glVertex2f(4.25 + shiftX2, -2.32);
glVertex2f(4.35 + shiftX2, -2.54);

glVertex2f(4.25 + shiftX2, -2.32);
glVertex2f(4.21 + shiftX2, -2.54);

glVertex2f(3.88 + shiftX2, -2.32);
glVertex2f(3.99 + shiftX2, -2.53);

glVertex2f(3.88 + shiftX2, -2.32);
glVertex2f(3.84 + shiftX2, -2.54);

glVertex2f(3.52 + shiftX2, -2.32);
glVertex2f(3.63 + shiftX2, -2.54);

glVertex2f(3.52 + shiftX2, -2.32);
glVertex2f(3.47 + shiftX2, -2.55);

glVertex2f(4.06 + shiftHandX2, -2.06); // K1
glVertex2f(3.91 + shiftHandX2, -2.06); // L1

glVertex2f(3.70 + shiftHandX2, -2.07); // M1
glVertex2f(3.51 + shiftHandX2, -2.06); // N1

glVertex2f(4.64 + shiftHandX2, -2.37); // O1
glVertex2f(4.47 + shiftHandX2, -2.36); // P1

glVertex2f(4.28 + shiftHandX2, -2.36); // Q1
glVertex2f(4.11 + shiftHandX2, -2.36); // R1

glVertex2f(3.91 + shiftHandX2, -2.36); // S1
glVertex2f(3.73 + shiftHandX2, -2.36); // T1

glVertex2f(3.55 + shiftHandX2, -2.36); // U1
glVertex2f(3.34 + shiftHandX2, -2.35); // V1


glEnd();
glLineWidth(1.0f);
glPopMatrix();





//Second Tank
glPushMatrix();
glTranslatef(tank1X, 0.0f, 0.0f);
float shiftX = -1.3;  // move right
float shiftY = 0.2;  // move up

glColor3f(0.0, 0.45, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(5.70 + shiftX, -2.10 + shiftY);
    glVertex2f(5.95 + shiftX, -2.40 + shiftY);
    glVertex2f(7.25 + shiftX, -2.40 + shiftY);
    glVertex2f(7.55 + shiftX, -2.15 + shiftY);
    glVertex2f(7.30 + shiftX, -1.95 + shiftY);
    glVertex2f(5.95 + shiftX, -1.92 + shiftY);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(5.70 + shiftX, -2.10 + shiftY);
    glVertex2f(5.95 + shiftX, -2.40 + shiftY);
    glVertex2f(7.25 + shiftX, -2.40 + shiftY);
    glVertex2f(7.55 + shiftX, -2.15 + shiftY);
    glVertex2f(7.30 + shiftX, -1.95 + shiftY);
    glVertex2f(5.95 + shiftX, -1.92 + shiftY);
glEnd();

glColor3f(0.0, 0.65, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.20 + shiftX, -1.92 + shiftY);
    glVertex2f(7.00 + shiftX, -1.92 + shiftY);
    glVertex2f(6.85 + shiftX, -1.72 + shiftY);
    glVertex2f(6.35 + shiftX, -1.72 + shiftY);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(6.20 + shiftX, -1.92 + shiftY);
    glVertex2f(7.00 + shiftX, -1.92 + shiftY);
    glVertex2f(6.85 + shiftX, -1.72 + shiftY);
    glVertex2f(6.35 + shiftX, -1.72 + shiftY);
glEnd();

glColor3f(0.0, 0.50, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.45 + shiftX, -1.90 + shiftY);
    glVertex2f(6.75 + shiftX, -1.90 + shiftY);
    glVertex2f(6.78 + shiftX, -2.05 + shiftY);
    glVertex2f(6.42 + shiftX, -2.05 + shiftY);
glEnd();

// Tank gun (barrel)
glColor3f(0.25, 0.25, 0.25);
glBegin(GL_POLYGON);
    glVertex2f(6.55 + shiftX, -1.88 + shiftY);
    glVertex2f(6.65 + shiftX, -1.85 + shiftY);
    glVertex2f(5.30 + shiftX, -1.35 + shiftY);
    glVertex2f(5.20 + shiftX, -1.45 + shiftY);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(6.55 + shiftX, -1.88 + shiftY);
    glVertex2f(6.65 + shiftX, -1.85 + shiftY);
    glVertex2f(5.30 + shiftX, -1.35 + shiftY);
    glVertex2f(5.20 + shiftX, -1.45 + shiftY);
glEnd();

// Wheels
glColor3f(0.1, 0.1, 0.1);
drawCircle(6.15 + shiftX, -2.30 + shiftY, 0.10);
drawCircle(6.45 + shiftX, -2.30 + shiftY, 0.10);
drawCircle(6.75 + shiftX, -2.30 + shiftY, 0.10);
drawCircle(7.05 + shiftX, -2.30 + shiftY, 0.10);
glPopMatrix();




//1st tank

 glPushMatrix();
 glTranslatef(tank1X, 0.0f, 0.0f);

  glColor3f(0.0, 0.45, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(5.70, -2.10);
    glVertex2f(5.95, -2.40);
    glVertex2f(7.25, -2.40);
    glVertex2f(7.55, -2.15);
    glVertex2f(7.30, -1.95);
    glVertex2f(5.95, -1.92);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(5.70, -2.10);
    glVertex2f(5.95, -2.40);
    glVertex2f(7.25, -2.40);
    glVertex2f(7.55, -2.15);
    glVertex2f(7.30, -1.95);
    glVertex2f(5.95, -1.92);
glEnd();

glColor3f(0.0, 0.65, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.20, -1.92);
    glVertex2f(7.00, -1.92);
    glVertex2f(6.85, -1.72);
    glVertex2f(6.35, -1.72);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(6.20, -1.92);
    glVertex2f(7.00, -1.92);
    glVertex2f(6.85, -1.72);
    glVertex2f(6.35, -1.72);
glEnd();

glColor3f(0.0, 0.50, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.45, -1.90);
    glVertex2f(6.75, -1.90);
    glVertex2f(6.78, -2.05);
    glVertex2f(6.42, -2.05);
glEnd();
 // Tank gun (barrel)
glColor3f(0.25, 0.25, 0.25);
glBegin(GL_POLYGON);
    glVertex2f(6.55, -1.88);
    glVertex2f(6.65, -1.85);
    glVertex2f(5.30, -1.35);
    glVertex2f(5.20, -1.45);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(6.55, -1.88);
    glVertex2f(6.65, -1.85);
    glVertex2f(5.30, -1.35);
    glVertex2f(5.20, -1.45);
glEnd();
// WHeel
glColor3f(0.1, 0.1, 0.1);
drawCircle(6.15, -2.30, 0.10);
drawCircle(6.45, -2.30, 0.10);
drawCircle(6.75, -2.30, 0.10);
drawCircle(7.05, -2.30, 0.10);
glPopMatrix();


//   Left Tank
glPushMatrix();
glTranslatef(tank2X, 0.0f, 0.0f);
//float shiftX1 = -12.9;  // move right
//float shiftY1 = 0.08;  // move up

glColor3f(0.0, 0.45, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(5.70 + shiftX1, -2.10 + shiftY1);
    glVertex2f(5.95 + shiftX1, -2.40 + shiftY1);
    glVertex2f(7.25 + shiftX1, -2.40 + shiftY1);
    glVertex2f(7.55 + shiftX1, -2.15 + shiftY1);
    glVertex2f(7.30 + shiftX1, -1.95 + shiftY1);
    glVertex2f(5.95 + shiftX1, -1.92 + shiftY1);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(5.70 + shiftX1, -2.10 + shiftY1);
    glVertex2f(5.95 + shiftX1, -2.40 + shiftY1);
    glVertex2f(7.25 + shiftX1, -2.40 + shiftY1);
    glVertex2f(7.55 + shiftX1, -2.15 + shiftY1);
    glVertex2f(7.30 + shiftX1, -1.95 + shiftY1);
    glVertex2f(5.95 + shiftX1, -1.92 + shiftY1);
glEnd();

glColor3f(0.0, 0.65, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.20 + shiftX1, -1.92 + shiftY1);
    glVertex2f(7.00 + shiftX1, -1.92 + shiftY1);
    glVertex2f(6.85 + shiftX1, -1.72 + shiftY1);
    glVertex2f(6.35 + shiftX1, -1.72 + shiftY1);
glEnd();

glColor3f(0,0,0);
glBegin(GL_LINE_LOOP);
    glVertex2f(6.20 + shiftX1, -1.92 + shiftY1);
    glVertex2f(7.00 + shiftX1, -1.92 + shiftY1);
    glVertex2f(6.85 + shiftX1, -1.72 + shiftY1);
    glVertex2f(6.35 + shiftX1, -1.72 + shiftY1);
glEnd();

glColor3f(0.0, 0.50, 0.0);
glBegin(GL_POLYGON);
    glVertex2f(6.45 + shiftX1, -1.90 + shiftY1);
    glVertex2f(6.75 + shiftX1, -1.90 + shiftY1);
    glVertex2f(6.78 + shiftX1, -2.05 + shiftY1);
    glVertex2f(6.42 + shiftX1, -2.05 + shiftY1);
glEnd();


////////// Wheels //////
glColor3f(0.1, 0.1, 0.1);
drawCircle(6.15 + shiftX1, -2.30 + shiftY1, 0.10);
drawCircle(6.45 + shiftX1, -2.30 + shiftY1, 0.10);
drawCircle(6.75 + shiftX1, -2.30 + shiftY1, 0.10);
drawCircle(7.05 + shiftX1, -2.30 + shiftY1, 0.10);
glPopMatrix();
//Plane
    //body
if(planeMoving)
{
    glPushMatrix();
    glTranslatef(planeX, 0.0f, 0.0f);
    glColor3f(0.0, 0.0, 0.0);

glBegin(GL_QUADS);
    glVertex2f(4.5f, 1.3f);  // Top-left
    glVertex2f(5.4f, 1.3f);  // Top-right
    glVertex2f(5.4f, 1.25f);  // Bottom-right
    glVertex2f(4.5f, 1.1f);  // Bottom-left
glEnd();


//Head
    glColor3f(0.1, 0.2, 0.4);

glBegin(GL_TRIANGLES);
    glVertex2f(4.2f, 1.15f);
    glVertex2f(4.5f, 1.3f);
    glVertex2f(4.5f, 1.1f);
glEnd();


//Upper wing
    glColor3f(0.5, 0.5, 0.5);

glBegin(GL_QUADS);
    glVertex2f(4.5f, 1.3f);
    glVertex2f(4.9f, 1.3f);
    glVertex2f(5.1f, 1.45f);
    glVertex2f(4.9f, 1.45f);

glEnd();


//Lower wing
    glColor3f(0.5, 0.5, 0.5);

glBegin(GL_QUADS);
    glVertex2f(4.5f, 1.2f);
    glVertex2f(4.9f, 1.2f);
    glVertex2f(5.2f, 1);
    glVertex2f(5, 1);

glEnd();


   //back wing
    glColor3f(0.1, 0.2, 0.4);

glBegin(GL_QUADS);
    glVertex2f(5.4f, 1.45f);  // Top-left
    glVertex2f(5.45f, 1.45f);  // Top-right
    glVertex2f(5.4f, 1.3f);  // Bottom-rightt
    glVertex2f(5.2f, 1.3f);  // Bottom-left
glEnd();
glPopMatrix();
}


   /*glBegin(GL_POLYGON);
        glVertex2f(5.77, -2.13);//E1
        glVertex2f(6,-2.35);//F1
        glVertex2f(7.19,-2.35);//G1
        glVertex2f(7.39,-2.15);//H1
        glVertex2f(7.26,-1.99);//J1
        glVertex2f(5.92,-1.96);//I1
        glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(6.12,-1.91);//W1
        glVertex2f(6.9,-1.91);//Z1
        glVertex2f(6.78,-1.76);//A2
        glVertex2f(6.25,-1.76);//B2
        glEnd();

    glBegin(GL_POLYGON);
        glVertex2f(6.23,-1.89);//C2
        glVertex2f(6.79,-1.89);//D2
        glVertex2f(6.8,-2);//E2
        glVertex2f(6.23,-2.01);//F2
        glEnd();

    //////////////// GUn,,,,
    glBegin(GL_POLYGON);
        glVertex2f(6.23,-1.89);//C2
        glVertex2f(6.32,-1.87);//I2
        glVertex2f(5.49,-1.37);//H2
        glVertex2f(5.43,-1.54);//G2
        glEnd();*/


        // BULLET 1
    if(fire1)
        { glColor3f(0,0,0); drawCircle(bullet1X, bullet1Y, 0.02); }
    if(blast1)
        { glColor3f(1,0,0); drawCircle(bullet1X, bullet1Y, 0.08); }

    if(fire2)
        { glColor3f(0,0,0); drawCircle(bullet2X, bullet2Y, 0.02); }
    if(blast2)
        { glColor3f(1,0,0); drawCircle(bullet2X, bullet2Y, 0.08); }


if(soldierFire)
{
    glColor3f(1,0,0); // red bullets
    glLineWidth(0.5f);
    for(int i=0;i<6;i++)
    {
        glBegin(GL_LINES);
            glVertex2f(soldierBulletX[i], soldierBulletY[i]);
            glVertex2f(soldierBulletX[i] + 0.2, soldierBulletY[i]); // horizontal line
        glEnd();
    }
    glLineWidth(1.0f); // reset
}

if(soldier2Fire)
{
    glColor3f(1,0,0); // red bullets
    glLineWidth(0.5f);
    for(int i=0; i<6; i++)
    {
        glBegin(GL_LINES);
            glVertex2f(soldier2BulletX[i], soldier2BulletY[i]);
            glVertex2f(soldier2BulletX[i] - 0.2, soldier2BulletY[i]); // horizontal line, left
        glEnd();
    }
    glLineWidth(1.0f);
}

if(bombDropped)
{
    glColor3f(0.3,0.3,0.3); // gray bomb
    drawCircle(bombX, bombY, 0.07f);
}

if(bombBlast)
{
    glColor3f(1,0,0);  // red explosion
    drawCircle(bombX, bombY, 0.15f); // bigger than bomb
}
if(bombShot)
{
    glColor3f(0.3, 0.3, 0.3); // gray bomb
    drawCircle(bombX, bombY, 0.07f);
}









    glutSwapBuffers();


     //glFlush();
}

void renderBuildings() {
    //glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1.0f, 1.0f, 1.0f);

    //frame
    glBegin(GL_QUADS);
    glVertex2f(-8.48f, -2.56f);//a
    glVertex2f( 8.30f, -2.60f);//b
    glVertex2f( 8.30f,  2.96f);//c
    glVertex2f(-8.48f,  2.96f);//d
    glEnd();
    //glFlush();

    //Building side
    glBegin(GL_LINES);

    glColor3f(0.0f, 0.0f, 0.0f);

    //Line 1
    glVertex2f(-8.48, -1.23);
    glVertex2f(-8.29, -1.35);
    //line 2
    glVertex2f(-8.29, -1.35);
    glVertex2f(-8.26, -1.23);
    //Line 3
    glVertex2f(-8.26, -1.23);
    glVertex2f(-7.97,-1.38);
    //Line 4
    glVertex2f(-7.97,-1.38);
    glVertex2f(-7.76,-1.29);
    //line 5
    glVertex2f(-7.76,-1.29);
    glVertex2f(-7.58,-1.07);
    //line 6
    glVertex2f(-7.58,-1.07);
    glVertex2f(-7.25,-1.04);
    glEnd();
    //glFlush();

    //1st Building
   // glBegin(GL_LINES);

    /*glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-7.25, -1.77);//f
    glVertex2f(-7.17,-1.77);//n

    glVertex2f(-7.17,-1.77);//n
    glVertex2f(-7.17,1.28);//o

    glVertex2f(-7.17,1.28);//o
    glVertex2f(-7.25,1.28);//e

    glVertex2f(-7.25,1.28);//e
    glVertex2f(-7.25, -1.77);//f*/

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-7.25, -1.77);//f
    glVertex2f(-7.17,-1.77);//n
    glVertex2f(-7.17,1.28);//o
    glVertex2f(-7.25,1.28);//e
    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-7.09,1.16);//q
    glVertex2f(-7.09,1.07);//r
    glVertex2f(-5.87,1.05);//t
    glVertex2f(-5.87,1.14);//s
    glEnd();
    //glFlush();


    glBegin(GL_LINES);

    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-7.25, -1.77);//n
    glVertex2f(-5.96, -1.78);//c2

    glVertex2f(-5.96, -1.78);//c2
    glVertex2f(-5.84, -1.77);//d2

    glVertex2f(-5.96, -1.78);//c2
    glVertex2f(-5.96, -1.15);//b2

    glVertex2f(-5.96, -1.15);//b2
    glVertex2f(-5.84, -1.15);//a2

    glVertex2f(-5.84, -1.15);//a2
    glVertex2f(-5.84, -1.77);//d2

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.96, -1.78);//c2
    glVertex2f(-5.84, -1.77);//d2
    glVertex2f(-5.84, -1.15);//a2
    glVertex2f(-5.96, -1.15);//b2
    glEnd();
    //glFlush();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.84, -1.77);//d2
    glVertex2f(-5.53, -1.57);//e2

    glVertex2f(-5.53, -1.57);//e2
    glVertex2f(-5.39, 0.83);//s1

    glVertex2f(-5.39, 0.83);//s1
    glVertex2f(-5.59, 0.84);//r1

    glVertex2f(-5.59, 0.84);//r1
    glVertex2f(-5.6, 1.24);//q1

    glVertex2f(-5.6, 1.24);//q1
    glVertex2f(-5.66, 1.49);//p1

    glVertex2f(-5.66, 1.49);//p1
    glVertex2f(-5.74, 1.49);//o1

    glVertex2f(-5.74, 1.49);//o1
    glVertex2f(-5.85, 1.65);//n1

    glVertex2f(-5.85, 1.65);//n1
    glVertex2f(-5.85, 1.5);//k1

    glVertex2f(-6.60, 1.49);//j1
    glVertex2f(-6.71, 1.74);//i1

    glVertex2f(-6.77, 1.17);//e1
    glVertex2f(-7.09,1.16);//q

    glVertex2f(-7.09,1.07);//r
    glVertex2f(-7.02,1.07);//l2

    glVertex2f(-7.02,1.07);//l2
    glVertex2f(-7.02,0.95);//m2

    glVertex2f(-7.02,0.95);//m2
    glVertex2f(-7.12,0.95);//n2

    glVertex2f(-7.12,0.95);//n2
    glVertex2f(-7.12,0.86);//o2

    glVertex2f(-7.12,0.86);//o2
    glVertex2f(-7.19,0.86);//p2

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.85, 1.5);//k1
    glVertex2f(-5.85, 1.37);//m1
    glVertex2f(-6.61, 1.36);//l1
    glVertex2f(-6.60, 1.49);//j1

    glEnd();
    //glFlush();

    glBegin(GL_TRIANGLES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.71, 1.74);//i1
    glVertex2f(-6.76, 1.57);//q2
    glVertex2f(-6.87, 1.57);//r2

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.76, 1.57);//q2
    glVertex2f(-6.87, 1.57);//r2
    glVertex2f(-6.87, 1.26);//g1
    glVertex2f(-6.77, 1.26);//h1

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.87, 1.26);//g1
    glVertex2f(-6.77, 1.26);//h1
    glVertex2f(-6.71, 1.17);//f1
    glVertex2f(-6.77, 1.17);//e1

    glEnd();
    //glFlush();

    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);

    //glVertex2f(-5.66, 1.49);//p1
    //glVertex2f(-5.6, 1.24);//q1
    //glVertex2f(-5.59, 0.84);//r1
    //glVertex2f(-5.39, 0.83);//s1
    glVertex2f(-5.53, -1.57);//e2
    glVertex2f(-5.84, -1.77);//d2
    glVertex2f(-5.84, -1.15);//a2
    glVertex2f(-5.71, -1.11);//z1
    glVertex2f(-5.62, -0.71);//w1
    glVertex2f(-5.6, -0.4);//s2
    glVertex2f(-5.73, -0.36);//v1
    glVertex2f(-5.75, -0.15);//u1
    glVertex2f(-5.89, -0.07);//t1
    //glVertex2f(-5.66, 1.49);//p1
    //glVertex2f(-5.74, 1.49);//o1

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.75, -0.15);//u1
    glVertex2f(-5.89, -0.07);//t1
    glVertex2f(-5.85, 1.65);//n1
    //glVertex2f(-5.66, 1.49);//p1
    glVertex2f(-5.74, 1.49);//o1

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.46, -1.56);//i2
    glVertex2f(-6.66, -1.56);//j2
    glVertex2f(-6.66, -1.77);//k2
    glVertex2f(-6.46, -1.77);//h2

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.71, 0.01);//a1
    glVertex2f(-6.43, 0.01);//b1
    glVertex2f(-6.43, -0.97);//d1
    glVertex2f(-6.71, -0.97);//c1

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.71, 0.86);//u
    glVertex2f(-6.4, 0.86);//v
    glVertex2f(-6.4, 0.17);//z
    glVertex2f(-6.71, 0.17);//w

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.71, -1.12);//t2
    glVertex2f(-6.45, -1.12);//u2
    glVertex2f(-6.45, -1.43);//w2
    glVertex2f(-6.71, -1.43);//v2

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.13, 0.77);//z2
    glVertex2f(-5.9, 0.77);//a3
    glVertex2f(-5.9, 0.63);//c3
    glVertex2f(-6.13, 0.63);//b3

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.16, 0.45);//d3
    glVertex2f(-5.91, 0.45);//e3
    glVertex2f(-5.91, 0.33);//g3
    glVertex2f(-6.16, 0.33);//f3

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.2, -0.2);//h3
    glVertex2f(-5.9, -0.2);//i3
    glVertex2f(-5.9, -0.33);//j3
    glVertex2f(-6.2, -0.33);//k3

    glEnd();
    //glFlush();

    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-6.16, -0.82);//l3
    glVertex2f(-5.94, -0.82);//m3
    glVertex2f(-5.94, -0.96);//o3
    glVertex2f(-6.16, -0.96);//n3

    glEnd();
    //glFlush();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.53, -1.57);//e2
    glVertex2f(-5.34, -1.5);//g2

    glVertex2f(-5.34, -1.5);//g2
    glVertex2f(-5.39, -1.37);//f2

    glVertex2f(-5.39, -1.37);//f2
    glVertex2f(-5.03, -1.37);//p3

    glVertex2f(-5.03, -1.37);//p3
    glVertex2f(-5, -1.27);//q3

    glEnd();
    //glFlush();

    //2nd building
    // // //

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-5.14, -1.73);//r3
    glVertex2f(-5.03, -1.37);//p3

    glVertex2f(-5.03, -1.37);//p3
    glVertex2f(-5, -1.27);//q3

    glVertex2f(-5, -1.27);//q3
    glVertex2f(-4.94, -1.11);//u3

    glEnd();
    //glFlush();

    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-4.94, -1.11);//u3
    glVertex2f(-4.75, -0.98);//l4
    glVertex2f(-4.69, -0.75);//v3
    glVertex2f(-4.62, -0.47);//m4
    glVertex2f(-4.63, -0.28);//w3
    glVertex2f(-4.72, -0.09);//z3
    //glVertex2f(-4.84, -0.21);//c4
    glVertex2f(-4.75, -0.24);//n4
    glVertex2f(-4.85, -0.27);//o4
    glVertex2f(-4.84, -0.35);//t3
    glVertex2f(-4.81, -0.47);//b4
    glVertex2f(-4.84, 0.81);//a4

    glEnd();
    //glFlush();

    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-4.84, -0.21);//c4
    glVertex2f(-4.8, 0.68);//d4

    glVertex2f(-4.8, 0.68);//d4
    glVertex2f(-4.86, 0.69);//i4

    glVertex2f(-4.86, 0.69);//i4
    glVertex2f(-4.9, 0.81);//e4

    glVertex2f(-4.9, 0.81);//e4
    glVertex2f(-4.39, 0.88);//p4

    glVertex2f(-4.39, 0.88);//p4
    glVertex2f(-3.84, 0.81);//f4

    glVertex2f(-3.84, 0.81);//f4
    glVertex2f(-3.88, 0.69);//h4

    glVertex2f(-3.88, 0.69);//h4
    glVertex2f(-3.94, 0.68);//g4

    glVertex2f(-3.94, 0.68);//g4
    glVertex2f(-4.39, 0.74);//q4

    glVertex2f(-4.39, 0.74);//q4
    glVertex2f(-4.8, 0.68);//d4

    glVertex2f(-3.94, 0.68);//g4
    glVertex2f(-3.92, -0.11);//j4

    glVertex2f(-3.92, -0.11);//j4
    glVertex2f(-3.83, -0.8);//k4

    glVertex2f(-3.83, -0.8);//k4
    glVertex2f(-3.65, -1.55);//s3

    glVertex2f(-3.65, -1.55);//s3
    glVertex2f(-3.64, -1.74);//r4

    glEnd();
    //glFlush();

    //2nd building smoke
    glBegin(GL_POLYGON);
    glColor3f(0.5f, 0.5f, 0.5f);

    glVertex2f(-4.42f, 0.96f);//q1
    glVertex2f(-4.43f, 1.06f);//r1
    glVertex2f(-4.28f, 1.13f);//s1
    glVertex2f(-4.2f, 1.2f);//t1
    glVertex2f(-4.71f, 1.2f);//u1
    glVertex2f(-4.72f, 1.46f);//v1
    glVertex2f(-4.52f, 1.69f);//w1
    glVertex2f(-4.33f, 1.81f);//z1
    glVertex2f(-4.23f, 1.91f);//a2
    glVertex2f(-4.23f, 2.06f);//b2
    glVertex2f(-4.31f, 2.14f);//c2
    glVertex2f(-4.43f, 2.16f);//d2
    glVertex2f(-4.42f, 2.25f);//e2
    glVertex2f(-4.37f, 2.34f);//f2
    glVertex2f(-4.32f, 2.28f);//g2
    glVertex2f(-4.34f, 2.22f);//h2
    glVertex2f(-4.22f, 2.17f);//i2
    glVertex2f(-4.1f, 2.09f);//j2
    glVertex2f(-4.04f, 1.92f);//k2
    glVertex2f(-4.04f, 1.82f);//l2
    glVertex2f(-4.06f, 1.71f);//m2
    glVertex2f(-4.26f, 1.69f);//n2
    glVertex2f(-4.39f, 1.63f);//o2
    glVertex2f(-4.41f, 1.55f);//p2
    glVertex2f(-4.32f, 1.51f);//q2
    glVertex2f(-4.19f, 1.47f);//r2
    glVertex2f(-3.97f, 1.34f);//s2
    glVertex2f(-3.89f, 1.2f);//t2
    glVertex2f(-4.16f, 1.05f);//u2
    glVertex2f(-4.23f, 1.07f);//v2
    glVertex2f(-4.29f, 1.08f);//w2
    glVertex2f(-4.38f, 1.06f);//z2
    glVertex2f(-4.41f, 1.02f);//a3

    glEnd();
    //glFlush();


    //road DDA LINE

    /*glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-8.48f, -2.56f);//a
    glVertex2f(8.30f, -2.60f);//b

    glVertex2f(8.30f, -2.60f);//b
    glVertex2f(8.27f, -1.83f);//z4

    glVertex2f(8.27f, -1.83f);//z4
    glVertex2f(-8.48f, -1.85f);//p-

    glVertex2f(-8.48f, -1.85f);//p
    glVertex2f(-8.48f, -2.56f);//a

    glEnd();
    glFlush();*/

    //1st line

    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(2.0);

    float x1= -8.48f, y1= -2.56f, x2= 8.30, y2=-2.60;
    float dx= x2-x1;
    float dy= y2- y1;

    float m= dy/dx;

    int step;
    if(fabs(dx)>fabs(dy))
    {
        step=fabs(dx);
    }
    else
    {
        step=fabs(dy);
    }

    float x=x1;
    float y=y1;

    glBegin(GL_LINE_STRIP);
    //glVertex2f(x,y);
    int i;

    for(i=0; i<=step;i++)
    {
        glVertex2f(x,y);
        x=x+(dx/step);
        y=y+(dy/step);
    }

    glEnd();
    //glFlush();

    // 2nd Line road

    glColor3f(0.0f,0.0f,0.0f);
    glPointSize(2.0);

    float x11= -8.48f, y11= -1.85f;
    float x21=  8.27f, y21= -1.83f;

    float dx1= x21 - x11;
    float dy1= y21 - y11;

    float m1=dy1 / dx1;

    int step1;
    if(fabs(dx1)>fabs(dy1))
    {
        step1 = fabs(dx1);
    }

    else
    {
        step1 = fabs(dy1);
    }

    float xn = x11;
    float yn = y11;

    glBegin(GL_LINE_STRIP);
    glVertex2f(xn, yn);
    int i1;

    for(i1 = 0; i1 <= step1; i1++)
    {
        glVertex2f(xn,yn);
        xn=xn+(dx1/step1);
        yn=yn+(dy1/step1);

    }
    glEnd();
    //glFlush();

    //3rd building
    //Susmita


glColor3f(0.0f, 0.0f, 0.0f);
glPointSize(2.0f);

/* Line d5 to e5 */
midPointLine(0.63f, -2.23f, 2.8f, -2.22f);

/* Line f5 to g5 */
midPointLine(-8.34f, -2.23f, -6.09f, -2.22f);

/* Line h5 to i5 */
midPointLine(-5.37f, -2.23f, -3.32f, -2.22f);

//glFlush();


    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-3.68f, -1.57f);//e
    glVertex2f(-3.52f, -0.28f);//f

    glVertex2f(-3.52f, -0.28f);//f
    glVertex2f(-3.43f, 0.96f);//g

    glVertex2f(-3.43f, 0.96f);//g
    glVertex2f(-3.42f, 1.25f);//h

    glVertex2f(-3.42f, 1.25f);//h
    glVertex2f(-3.42f, 2.1f);//i

    glVertex2f(-3.42f, 2.1f);//i
    glVertex2f(-3.46f, 2.13f);//j

    glVertex2f(-3.46f, 2.13f);//j
    glVertex2f(-3.5f, 2.2f);//k

    glVertex2f(-3.5f, 2.2f);//k
    glVertex2f(-3.06f, 2.32f);//l

    glVertex2f(-3.06f, 2.32f);//l
    glVertex2f(-2.57f, 2.22f);//m

    glVertex2f(-2.57f, 2.22f);//m
    glVertex2f(-2.61f, 2.13f);//n

    glVertex2f(-2.61f, 2.13f);//n
    glVertex2f(-2.66f, 2.1f);//o

    glVertex2f(-3.42f, 2.1f);//i
    glVertex2f(-3.06f, 2.19f);//n1

    glVertex2f(-3.06f, 2.19f);//n1
    glVertex2f(-2.66f, 2.1f);//o

    glVertex2f(-2.66f, 2.1f);//o
    glVertex2f(-2.64f, 1.24f);//p

    glVertex2f(-2.64f, 1.24f);//p
    glVertex2f(-2.64f, 1.00f);//q

    glVertex2f(-2.64f, 1.00f);//q
    glVertex2f(-2.57f, -0.13f);//k1

    glVertex2f(-2.57f, -0.13f);//k1
    glVertex2f(-2.49f, -1.14f);//j1

    glEnd();
   // glFlush();


    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-2.95f, -1.68f);//t
    glVertex2f(-3.1f, -1.68f);//u
    glVertex2f(-3.12f, -1.55f);//v
    glVertex2f(-3.29f, -1.58f);//w
    glVertex2f(-3.28f, -1.2f);//z
    glVertex2f(-3.36f, -1.13f);//a1
    glVertex2f(-3.15f, -0.32f);//b1
    glVertex2f(-3.03f, -0.32f);//c1
    glVertex2f(-2.89f, -0.02f);//d1
    glVertex2f(-2.75f, 0.02f);//e1
    glVertex2f(-2.72f, -0.49f);//f1
    glVertex2f(-2.66f, -1.15f);//g1
    glVertex2f(-2.56f, -1.35f);//h1
    glVertex2f(-2.63f, -1.48f);//i1

    glEnd();
    //glFlush();

    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-3.43f, 0.96f);//g
    glVertex2f(-3.42f, 1.25f);//h
    glVertex2f(-3.04f, 1.29f);//o1
    glVertex2f(-2.64f, 1.24f);//p
    glVertex2f(-2.64f, 1.00f);//q
    glVertex2f(-3.03f, 1.04f);//p1

    glEnd();
    //glFlush();



    //Shanto
    //middle building
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-0.44f, -1.72f);//E
    glVertex2f(0.08f, -1.74f);//F

    glVertex2f(0.08f, -1.74f);//F
    glVertex2f(0.68f, -1.72f);//G

    glVertex2f(0.68f, -1.72f);//G
    glVertex2f(0.70827f, -0.76262f);//H


    glVertex2f(-0.44f, -1.72f);//E
    glVertex2f(-2.91147f, -1.70116f);//L3

    glVertex2f(0.70827f, -0.76262f);//H
    glVertex2f(0.54709f, -0.88082f);//I

    glVertex2f(0.54709f, -0.88082f);//I
    glVertex2f(0.35367f, -0.91306f);//J

     glVertex2f(0.35367f, -0.91306f);//J
     glVertex2f(0.33218f, -0.6874f);//k

     glVertex2f(0.33218f, -0.6874f);//k
     glVertex2f(0.27845f, -0.36504f);//L

     glVertex2f(0.27845f, -0.36504f);//L
     glVertex2f(0.46113f, -0.13938f);//M

     glVertex2f(0.46113f, -0.13938f);//M
     glVertex2f(0.54709f, -0.88082f);//I


     glVertex2f(0.46113f, -0.13938f);//M
     glVertex2f(0.762f, -0.0964f);//N

     glVertex2f(0.762f, -0.0964f);//N
     glVertex2f(0.79424f, 0.32268f);//O

     glVertex2f(0.79424f, 0.32268f);//O
     glVertex2f(0.62231f, 0.36566f);//P

     glVertex2f(0.62231f, 0.36566f);//P
     glVertex2f(0.70827f, 1.36499f);//Q

      glVertex2f(0.70827f, 1.36499f);//Q
      glVertex2f(0.68139f, 1.46052f);//R

      glVertex2f(0.68139f, 1.46052f);//R
      glVertex2f(0.61061f, 1.45294f);//S

      glVertex2f(0.61061f, 1.45294f);//S
      glVertex2f(0.54995f, 1.36447f);//T

      glVertex2f(0.54995f, 1.36447f);//T
      glVertex2f(0.30223f, 1.57932f);//U

      glEnd();
      //glFlush();

      glBegin(GL_LINES);
     glColor3f(0.0f, 0.0f, 0.0f);

      glVertex2f(0.4994f, 1.70065f);//V
      glVertex2f(0.47159f, 1.15466f);//W

      glVertex2f(0.36543f, 1.82957f);//Z
      glVertex2f(0.36543f, 1.22039f);//A1

      glVertex2f(0.36543f, 1.22039f);//A1
      glVertex2f(0.33221f, 0.71795f);//B1

      glVertex2f(0.41232f, 1.16859f);//C1
      glVertex2f(0.40732f, 1.05843f);//D1

      glVertex2f(0.40732f, 1.05843f);//D1
      glVertex2f(0.49244f, 1.04091f);//E1

      glVertex2f(0.49244f, 1.04091f);//E1
      glVertex2f(0.48993f, 0.73798f);//F1

      glVertex2f(0.48993f, 0.73798f);//F1
      glVertex2f(0.55753f, 0.84062f);//G1

      glVertex2f(0.54995f, 1.36447f);//T
      glVertex2f(0.54751f, 0.62532f);//H1

      glVertex2f(0.54751f, 0.62532f);//H1
      glVertex2f(0.21955f, 0.73297f);//I1

      glVertex2f(0.21955f, 0.73297f);//I1
      glVertex2f(0.22113f, 2.26019f);//J1

      glVertex2f(0.22113f, 2.26019f);//J1
      glVertex2f(-0.10164f, 1.88046f);//K1

      glVertex2f(-0.10164f, 1.88046f);//K1
      glVertex2f(-0.13012f, 1.46276f);//L1

      glVertex2f(0.21955f, 0.73297f);//I1
      glVertex2f(0.08f, -1.74f);//F


      glVertex2f(-0.13012f, 1.46276f);//L1
      glVertex2f(-0.22191f, 1.44124f);//M1

      glVertex2f(-0.22191f, 1.44124f);//M1
      glVertex2f(-0.20253f, 2.11724f);//N1

      glVertex2f(-0.20253f, 2.11724f);//N1
      glVertex2f(-0.32f, 2.23f);   // O1


      // O1 to P1
    glVertex2f(-0.32f, 2.23f);   // O1
    glVertex2f(-0.47f, 2.14f);   // P1

    // P1 to Q1
    glVertex2f(-0.47f, 2.14f);   // P1
    glVertex2f(-0.53f, 1.43f);   // Q1

    // Q1 to R1
    glVertex2f(-0.53f, 1.43f);   // Q1
    glVertex2f(-0.75f, 1.18f);   // R1

    // R1 to S1
    glVertex2f(-0.75f, 1.18f);   // R1
    glVertex2f(-0.14f, 1.13f);   // S1

    // S1 to T1
    glVertex2f(-0.14f, 1.13f);   // S1
    glVertex2f(-0.12f, 0.61f);   // T1

    // T1 to U1
    glVertex2f(-0.12f, 0.61f);   // T1
    glVertex2f(-0.80f, 0.56f);   // U1

    // U1 to V1
    glVertex2f(-0.80f, 0.56f);   // U1
    glVertex2f(-0.85f, 0.80f);   // V1

    // V1 to W1
    glVertex2f(-0.85f, 0.80f);   // V1
    glVertex2f(-0.98f, 0.90f);   // W1

    // W1 to Z1
    glVertex2f(-0.98f, 0.90f);   // W1
    glVertex2f(-1.01f, 1.51f);   // Z1

    // Z1 to A2
    glVertex2f(-1.01f, 1.51f);   // Z1
    glVertex2f(-1.09f, 1.52f);   // A2

    // A2 to B2
    glVertex2f(-1.09f, 1.52f);   // A2
    glVertex2f(-1.09f, 0.86f);   // B2

    // B2 to C2
    glVertex2f(-1.09f, 0.86f);   // B2
    glVertex2f(-1.08f, 0.54f);   // C2

    // C2 to D2
    glVertex2f(-1.08f, 0.54f);   // C2
    glVertex2f(-1.21f, 0.63f);   // D2

    // D2 to E2
    glVertex2f(-1.21f, 0.63f);   // D2
    glVertex2f(-1.23f, 0.90f);   // E2

    glVertex2f(-1.23f, 0.90f);   // E2
    glVertex2f(-1.09f, 0.86f);   // B2


    //glVertex2f(-0.83842f, 1.81733f);   // H2
    //glVertex2f(-0.77231f, 0.7298f);   // I2

    glVertex2f(-0.48472f, 1.07688f);   // j2
    glVertex2f(-0.49464f, 0.68682f);   // k2

    glVertex2f(-0.49464f, 0.68682f);   // k2
    glVertex2f(-0.86231f, 0.7298f);   // I2

    //glVertex2f(-0.39217f, 1.08349f);   // L2
    glVertex2f(-0.20706f, 1.10994f);   // M2
    glVertex2f(-0.48472f, 1.07688f);   // j2


    glVertex2f(-0.2f, 0.6f);   // N2
    glVertex2f(-0.20706f, 1.10994f);   // M2

    glVertex2f(-0.2f, 0.6f);   // N2
    glVertex2f(-0.80f, 0.56f);   // U1

    glVertex2f(-1.21f, 0.63f);   // D2
    glVertex2f(-1.23885f, -0.48515f);   // O2

    glVertex2f(-0.98f, 0.90f);   // W1
    glVertex2f(-1, -0.4f);   // P2

    glVertex2f(-0.80f, 0.56f);   // U1
    glVertex2f(-0.83631f, -0.56352f);   // Q2

    glVertex2f(-0.44f, -1.72f);//E
    glVertex2f(-0.53823, -0.78079);//R2

    glVertex2f(-0.53823, -0.78079);//R2
    glVertex2f(-0.83631f, -0.56352f);   // Q2

    glVertex2f(-0.83631f, -0.56352f);   // Q2
    glVertex2f(-1, -0.4f);   // P2

    glVertex2f(-1, -0.4f);   // P2
    glVertex2f(-1.23885f, -0.48515f);   // O2


      glEnd();
      //glFlush();

      //Window
       glBegin(GL_POLYGON);
     glColor3f(0.0f, 0.0f, 0.0f);

     glVertex2f(-0.45, -1.5);//S2
     glVertex2f(-0.2161, -1.45792);//T2
     glVertex2f(-0.19638, -1.72088);//U2
     glVertex2f(-0.44f, -1.72f);//E

     glEnd();
      //glFlush();

     glBegin(GL_POLYGON);
     glColor3f(0.0f, 0.0f, 0.0f);

     glVertex2f(-0.48425f, -1.04375f);//V2
     glVertex2f(-0.17665f, -1.05033f);//W2
     glVertex2f(-0.19638f, -1.26727f);//Z2
     glVertex2f(-0.4448f, -1.26727f);//A3


      glEnd();
      //glFlush();

      /*glBegin(GL_POLYGON);
      glColor3f(0.0f, 0.0f, 0.0f);

      glVertex2f(-0.83731f, -0.56352f);//Q2
      glVertex2f(-0.17008f, -0.60329f);//J3
      glVertex2f(-0.19638f, -1.26727f);//K3
      glVertex2f(-0.16351f, -0.81366f);//R2


      glEnd();
      glFlush();*/


     glBegin(GL_POLYGON);
     glColor3f(0.0f, 0.0f, 0.0f);

      glVertex2f(-0.7749f, -0.14311f);//B3
      glVertex2f(-0.15036f, -0.11681f);//C3
      glVertex2f(-0.16351f, -0.32718f);//D3
      glVertex2f(-0.78804f, -0.32718f);//E3

      glEnd();
      //glFlush();

      glBegin(GL_POLYGON);
     glColor3f(0.0f, 0.0f, 0.0f);

      glVertex2f(-0.78721f, 0.31051f);//F3
      glVertex2f(-0.13064f, 0.3368f);//I3
      glVertex2f(-0.12406f, 0.13958f);//H3
      glVertex2f(-0.78804f, 0.09356f);//I3

     glEnd();
      //glFlush();


    //stone
    glBegin(GL_LINES);
     glColor3f(0.0f, 0.0f, 0.0f);

     glVertex2f(-2.91147f, -1.70116f);//L3
      glVertex2f(-2.78656f, -1.30014f);//M3

      glVertex2f(-2.78656f, -1.30014f);//M3
      glVertex2f(-2.62221f, -1.35273f);//N3

      glVertex2f(-2.62221f, -1.35273f);//N3
      glVertex2f(-2.33295f, -1.10292f);//O3

      glVertex2f(-2.33295f, -1.10292f);//O3
      glVertex2f(-1.83332f, -0.86625f);//P3

      glVertex2f(-1.83332f, -0.86625f);//P3
      glVertex2f(-1.51777f, -0.82681f);//Q3

      glVertex2f(-1.51777f, -0.82681f);//Q3
      glVertex2f(-1.23885f, -0.48515f);//Q3

      glVertex2f(0.68f, -1.72f);//G
      glVertex2f(1.37091f, -1.06918f);//R3

      glVertex2f(1.37091f, -1.06918f);//R3
      glVertex2f(0.5f, -0.5f);//S3

      glVertex2f(-2.91147f, -1.70116f);//L3
      glVertex2f(-2.3034f, -1.49863f);//T3

      glVertex2f(-2.3034f, -1.49863f);//T3
      glVertex2f(-2.33295f, -1.10292f);//O3

      glVertex2f(-2.3034f, -1.49863f);//T3
      glVertex2f(-2.16565f, -1.70121f);//B3

      glVertex2f(-2.3034f, -1.49863f);//T3
      glVertex2f(-1.93066f, -1.49053f);//U3

      glVertex2f(-1.93066f, -1.f);//U3
      glVertex2f(-2.33295f, -1.10292f);//O3

      glVertex2f(-1.93066f, -1.49053f);//U3
      glVertex2f(-1.44449f, -1.35278f);//V3

      glVertex2f(-1.07175f, -1.55535f);//W3
      glVertex2f(-1.44449f, -1.35278f);//V3

      glVertex2f(-1.07175f, -1.55535f);//W3
      glVertex2f(-1.12037f, -1.76603f);//Z3

      glVertex2f(-1.93066f, -1.49053f);//U3
      glVertex2f(-1.83332f, -0.86625f);//P3

      glVertex2f(-1.83332f, -0.86625f);//P3
      glVertex2f(-1.44449f, -1.35278f);//V3

      glVertex2f(-1.44449f, -1.35278f);//V3
      glVertex2f(-1, -0.4f);//P2

      glVertex2f(-1, -0.4f);//P2
      glVertex2f(-1.07175f, -1.55535f);//W3

      glVertex2f(-1.07175f, -1.55535f);//W3
      glVertex2f(-0.58425f, -1.04375f);//V2



     glEnd();
    //glFlush();

    /* ==========================================
    // Left Tower
    // ==========================================

    // Tower base and main body
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(-3.2f, -1.75f);  // bottom left
    glVertex2f(-2.5f, -1.75f);  // bottom right
    glVertex2f(-2.4f, -1.5f);   // right step
    glVertex2f(-2.35f, 0.5f);   // right side up
    glVertex2f(-2.4f, 1.2f);    // right top narrow
    glVertex2f(-2.5f, 1.8f);    // right top
    glVertex2f(-2.55f, 2.2f);   // chimney right
    glVertex2f(-2.6f, 2.5f);    // chimney top right
    glVertex2f(-2.8f, 2.6f);    // chimney peak
    glVertex2f(-3.0f, 2.5f);    // chimney top left
    glVertex2f(-3.05f, 2.2f);   // chimney left
    glVertex2f(-3.1f, 1.8f);    // left top
    glVertex2f(-3.2f, 1.2f);    // left top narrow
    glVertex2f(-3.25f, 0.5f);   // left side up
    glVertex2f(-3.3f, -1.5f);   // left step

    glEnd();
    glFlush();

    // Tower details - horizontal bands
    glBegin(GL_LINES);
    glColor3f(0.3f, 0.3f, 0.3f);

    glVertex2f(-3.25f, 0.0f);
    glVertex2f(-2.35f, 0.0f);

    glVertex2f(-3.2f, 0.8f);
    glVertex2f(-2.4f, 0.8f);

    glVertex2f(-3.15f, 1.5f);
    glVertex2f(-2.45f, 1.5f);

    glEnd();
    glFlush();*/



    //Susmita

    // Right wall of building (thick intact side) - NOW ON RIGHT
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(3.4f, -1.75f);
    glVertex2f(3.7f, -1.75f);
    glVertex2f(3.7f, 2.5f);
    glVertex2f(3.55f, 2.6f);
    glVertex2f(3.4f, 2.5f);
    glEnd();
    //glFlush();

    // Top extended part (roof structure)
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.3f, 2.3f);
    glVertex2f(3.4f, 2.3f);
    glVertex2f(3.4f, 2.5f);
    glVertex2f(2.2f, 2.4f);
    glEnd();
    //glFlush();

    // Left side wall/column (partial, damaged)
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.25f, -1.75f);
    glVertex2f(1.4f, -1.75f);
    glVertex2f(1.4f, -0.5f);
    glVertex2f(1.25f, -0.4f);
    glEnd();
    //glFlush();



    // Floor 1
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.4f, -1.55f);
    glVertex2f(3.4f, -1.55f);
    glVertex2f(3.4f, -1.48f);
    glVertex2f(1.4f, -1.48f);
    glEnd();
    //glFlush();

    // Floor 2
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.45f, -1.1f);
    glVertex2f(3.4f, -1.1f);
    glVertex2f(3.4f, -1.03f);
    glVertex2f(1.45f, -1.03f);
    glEnd();
    //glFlush();

    // Floor 3
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.55f, -0.65f);
    glVertex2f(3.4f, -0.65f);
    glVertex2f(3.4f, -0.58f);
    glVertex2f(1.55f, -0.58f);
    glEnd();
   // glFlush();

    // Floor 4
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.7f, -0.2f);
    glVertex2f(3.4f, -0.2f);
    glVertex2f(3.4f, -0.13f);
    glVertex2f(1.7f, -0.13f);
    glEnd();
    //glFlush();

    // Floor 5
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.9f, 0.25f);
    glVertex2f(3.4f, 0.25f);
    glVertex2f(3.4f, 0.32f);
    glVertex2f(1.9f, 0.32f);
    glEnd();
    //glFlush();

    // Floor 6
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.1f, 0.7f);
    glVertex2f(3.4f, 0.7f);
    glVertex2f(3.4f, 0.77f);
    glVertex2f(2.1f, 0.77f);
    glEnd();
    //glFlush();

    // Floor 7
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.25f, 1.15f);
    glVertex2f(3.4f, 1.15f);
    glVertex2f(3.4f, 1.22f);
    glVertex2f(2.25f, 1.22f);
    glEnd();
    //glFlush();

    // Floor 8
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.35f, 1.6f);
    glVertex2f(3.4f, 1.6f);
    glVertex2f(3.4f, 1.67f);
    glVertex2f(2.35f, 1.67f);
    glEnd();
    //glFlush();

    // Floor 9 (top)
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.4f, 2.05f);
    glVertex2f(3.4f, 2.05f);
    glVertex2f(3.4f, 2.12f);
    glVertex2f(2.4f, 2.12f);
    glEnd();


    // Column 1 (right side)
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(3.0f, -1.55f);
    glVertex2f(3.08f, -1.55f);
    glVertex2f(3.08f, 2.12f);
    glVertex2f(3.0f, 2.12f);
    glEnd();
    //glFlush();

    // Column 2 (middle)
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.5f, -1.55f);
    glVertex2f(2.58f, -1.55f);
    glVertex2f(2.58f, 1.22f);
    glVertex2f(2.5f, 1.22f);
    glEnd();
    //glFlush();

    // Column 3
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.0f, -1.55f);
    glVertex2f(2.08f, -1.55f);
    glVertex2f(2.08f, 0.32f);
    glVertex2f(2.0f, 0.32f);
    glEnd();
    //glFlush();


    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    // Beam 1 (bottom area)
    glVertex2f(1.5f, -1.48f);
    glVertex2f(3.0f, -1.1f);

    // Beam 2
    glVertex2f(1.6f, -1.03f);
    glVertex2f(2.5f, -0.65f);

    // Beam 3
    glVertex2f(1.8f, -0.58f);
    glVertex2f(2.5f, -0.2f);

    // Beam 4
    glVertex2f(2.0f, -0.13f);
    glVertex2f(2.5f, 0.25f);

    // Beam 5
    glVertex2f(2.2f, 0.32f);
    glVertex2f(2.5f, 0.7f);

    // Beam 6 (upper area)
    glVertex2f(2.3f, 0.77f);
    glVertex2f(2.5f, 1.15f);

    glEnd();
    //glFlush();

    // Diagonal damaged edge
    glBegin(GL_LINE_STRIP);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.25f, -0.5f);
    glVertex2f(1.45f, -1.03f);
    glVertex2f(1.55f, -0.58f);
    glVertex2f(1.7f, -0.13f);
    glVertex2f(1.9f, 0.32f);
    glVertex2f(2.1f, 0.77f);
    glVertex2f(2.25f, 1.22f);
    glVertex2f(2.35f, 1.67f);
    glVertex2f(2.4f, 2.12f);
    glVertex2f(2.3f, 2.5f);
    glEnd();
    //glFlush();

    // Bottom door/window frame
    glBegin(GL_LINE_LOOP);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(2.7f, -1.75f);
    glVertex2f(3.3f, -1.75f);
    glVertex2f(3.3f, -1.55f);
    glVertex2f(2.7f, -1.55f);
    glEnd();
    //glFlush();

    // Window frame vertical divider
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(3.0f, -1.75f);
    glVertex2f(3.0f, -1.55f);
    glEnd();
    //glFlush();

    // Small vertical elements
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f);

    glVertex2f(2.3f, 0.77f);
    glVertex2f(2.3f, 1.15f);

    glVertex2f(2.25f, 1.22f);
    glVertex2f(2.25f, 1.6f);

    glEnd();
    //glFlush();

    // Bottom base of building
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(1.25f, -1.75f);
    glVertex2f(3.7f, -1.75f);
    glVertex2f(3.7f, -1.68f);
    glVertex2f(1.25f, -1.68f);
    glEnd();
    //glFlush();

    glBegin(GL_LINES);

    /* ================= FRAME A B C D ================= */

    // A (-8.46, -2.55) -> B (8.32, -2.59)
    glVertex2f(-8.46, -2.55);   // A
    glVertex2f( 8.32, -2.59);   // B

    // B -> C (8.32, 2.98)
    glVertex2f( 8.32, -2.59);   // B
    glVertex2f( 8.32,  2.98);   // C

    // C -> D (-8.44, 2.96)
    glVertex2f( 8.32,  2.98);   // C
    glVertex2f(-8.44,  2.96);   // D

    // D -> A
    glVertex2f(-8.44,  2.96);   // D
    glVertex2f(-8.46, -2.55);   // A


    /* ================= HOUSE OUTLINE ================= */

    // E (5.02,-1.76) -> F (5,0.41)
    glVertex2f(5.02, -1.76);    // E
    glVertex2f(5.00,  0.41);    // F

    // F -> G (5.3,0.13)
    glVertex2f(5.00,  0.41);    // F
    glVertex2f(5.30,  0.13);    // G

    // G -> H (6,0)
    glVertex2f(5.30,  0.13);    // G
    glVertex2f(6.00,  0.00);    // H

    // H -> I (6.58,-0.07)
    glVertex2f(6.00,  0.00);    // H
    glVertex2f(6.58, -0.07);    // I

    // I -> J (7,0)
    glVertex2f(6.58, -0.07);    // I
    glVertex2f(7.00,  0.00);    // J

    // J -> K (6.86,-1.76)
    glVertex2f(7.00,  0.00);    // J
    glVertex2f(6.86, -1.76);    // K

    // K -> L (6.48,-1.44)
    //glVertex2f(6.86, -1.76);    // K
    //glVertex2f(6.48, -1.44);    // L

    // L -> M (6.2,-1.76)
    //glVertex2f(6.48, -1.44);    // L
   // glVertex2f(6.20, -1.76);    // M

    // J -> N (6.81,-0.3)
    glVertex2f(7.00,  0.00);    // J
    glVertex2f(6.81, -0.30);    // N

    // N -> O (6.4,-0.52)
    glVertex2f(6.81, -0.30);    // N
    glVertex2f(6.40, -0.52);    // O

    // O -> P (5.87,-0.37)
    glVertex2f(6.40, -0.52);    // O
    glVertex2f(5.87, -0.37);    // P

    // P -> Q (5.36,-0.37)
    glVertex2f(5.87, -0.37);    // P
    glVertex2f(5.36, -0.37);    // Q

    // Q -> R (5.35,-0.96)
    glVertex2f(5.36, -0.37);    // Q
    glVertex2f(5.35, -0.96);    // R

    // R -> S (5,-1)
    glVertex2f(5.35, -0.96);    // R
    glVertex2f(5.00, -1.00);    // S

    // E -> K
    glVertex2f(5.02, -1.76);    // E
    glVertex2f(6.86, -1.76);    // K

    // D2 -> L
    glVertex2f(6.5308,-0.43304);    // D2
    glVertex2f(6.51042,-1.79206);    // L


    /* ================= WINDOWS ================= */
    /* Window order EXACTLY as you requested */

    /* ---- Window 1 : Z - A1 - B1 - C1 ---- */
    glVertex2f(5.14, -1.10);    // Z
    glVertex2f(5.31, -1.12);    // A1

    glVertex2f(5.31, -1.12);    // A1
    glVertex2f(5.29, -1.34);    // C1

    glVertex2f(5.12, -1.34);    // B1
    glVertex2f(5.29, -1.34);    // C1


    glVertex2f(5.14, -1.10);    // Z
    glVertex2f(5.12, -1.34);    // B1


    /* ---- Window 2 : D1 - E1 - G1 - F1 ---- */
    glVertex2f(5.47, -1.11);    // D1
    glVertex2f(5.61, -1.10);    // E1

    glVertex2f(5.61, -1.10);    // E1
    glVertex2f(5.62, -1.34);    // G1

    glVertex2f(5.62, -1.34);    // G1
    glVertex2f(5.48, -1.35);    // F1

    glVertex2f(5.48, -1.35);    // F1
    glVertex2f(5.47, -1.11);    // D1


    /* ---- Window 3 : H1 - I1 - K1 - J1 ---- */
    glVertex2f(5.80, -1.10);    // H1
    glVertex2f(5.98, -1.11);    // I1

    glVertex2f(5.98, -1.11);    // I1
    glVertex2f(5.99, -1.36);    // K1

    glVertex2f(5.99, -1.36);    // K1
    glVertex2f(5.79, -1.34);    // J1

    glVertex2f(5.79, -1.34);    // J1
    glVertex2f(5.80, -1.10);    // H1


    /* ---- Window 4 : L1 - M1 - O1 - N1 ---- */
    glVertex2f(6.17, -1.10);    // L1
    glVertex2f(6.32, -1.10);    // M1

    glVertex2f(6.32, -1.10);    // M1
    glVertex2f(6.34, -1.37);    // O1

    glVertex2f(6.34, -1.37);    // O1
    glVertex2f(6.17, -1.35);    // N1

    glVertex2f(6.17, -1.35);    // N1
    glVertex2f(6.17, -1.10);    // L1

    // Window 6 (P1 Q1 R1 S1)
    glVertex2f(5.49, -0.57); glVertex2f(5.63, -0.57);
    glVertex2f(5.63, -0.57); glVertex2f(5.63, -0.84);
    glVertex2f(5.63, -0.84); glVertex2f(5.49, -0.84);
    glVertex2f(5.49, -0.84); glVertex2f(5.49, -0.57);

    // Window 7 (T1 U1 V1 W1)
    glVertex2f(5.80, -0.60); glVertex2f(5.96, -0.59);
    glVertex2f(5.96, -0.59); glVertex2f(5.98, -0.86);
    glVertex2f(5.98, -0.86); glVertex2f(5.80, -0.86);
    glVertex2f(5.80, -0.86); glVertex2f(5.80, -0.60);

    // Window 8 (Z1 A2 B2 C2)
    glVertex2f(6.16, -0.60); glVertex2f(6.32, -0.60);
    glVertex2f(6.32, -0.60); glVertex2f(6.33, -0.89);
    glVertex2f(6.33, -0.89); glVertex2f(6.16, -0.88);
    glVertex2f(6.16, -0.88); glVertex2f(6.16, -0.60);

    glEnd();
    //glFlush();

    //Susmita 3D

// -------- Sun Disc (Front face) ----------
/*glBegin(GL_POLYGON);
glColor3f(1.0f, 0.0f, 0.0f);

float x_center = 6.71f, y_center = 2.46f;
float radius = 0.3f;

for (float angle = 0; angle <= 360; angle += 1.0f)
{
    float x = x_center + radius * cos(angle * 3.1416f / 180);
    float y = y_center + radius * sin(angle * 3.1416f / 180);

    glVertex3f(x, y, -1.0f);
}
glEnd();


// -------- 3D Sun (Sphere) ----------
glPushMatrix();
glColor3f(1.0f, 0.0f, 0.0f);
glTranslatef(x_center, y_center, -1.2f);
glutSolidSphere(0.3, 40, 40);
glPopMatrix();


    glEnd();*/
    //glFlush();


}

void keyboard(unsigned char key, int x, int y)
{
    if(key == 'a') tank1X -= 0.5;
    if(key == 'd') tank1X += 0.5;

    if(key == 'j') tank2X -= 0.5;
    if(key == 'l') tank2X += 0.5;

    if(key == 'm') soldier1X += 0.3; // move soldiers right
    if(key == 'n') soldier1X -= 0.3; // move soldiers left

    if(key == 'b') soldier2X += 0.3; // move soldiers right
    if(key == 'v') soldier2X -= 0.3; // move soldiers left

    // FIRE BOTH TANKS
    if(key == 'f' && fire1 == 0 && fire2 == 0)
    {
        fire1 = 1;
        fire2 = 1;


        bullet1X = 5.30 + tank1X;
        bullet1Y = -1.35;


        float shiftX = -1.3;  // display function
        float shiftY = 0.2;
        bullet2X = 5.30 + shiftX + tank1X;
        bullet2Y = -1.35 + shiftY;
    }
    if(key == 'g' && soldierFire == 0)
{
    soldierFire = 1;

    // starting positions of all 6 soldiers
    soldierBulletX[0] = 3.91 + soldier1X;  soldierBulletY[0] = -2.06;
    soldierBulletX[1] = 3.51 + soldier1X;  soldierBulletY[1] = -2.06;
    soldierBulletX[2] = 4.47 + soldier1X;  soldierBulletY[2] = -2.36;
    soldierBulletX[3] = 4.11 + soldier1X;  soldierBulletY[3] = -2.36;
    soldierBulletX[4] = 3.73 + soldier1X;  soldierBulletY[4] = -2.36;
    soldierBulletX[5] = 3.34 + soldier1X;  soldierBulletY[5] = -2.35;
}
if(key == 'h' && soldier2Fire == 0) // left soldier fire
{
    soldier2Fire = 1; // mark as firing

    // starting positions of all 6 bullets for left soldier
    float shiftX2 = -8.8f; // same shift as in display
    float soldier2X_temp = soldier2X; // current translation

    soldier2BulletX[0] = 4.06 + shiftX2 + soldier2X_temp;  soldier2BulletY[0] = -2.06;
    soldier2BulletX[1] = 3.7 + shiftX2 + soldier2X_temp;  soldier2BulletY[1] = -2.07;
    soldier2BulletX[2] = 4.64 + shiftX2 + soldier2X_temp;  soldier2BulletY[2] = -2.37;
    soldier2BulletX[3] = 4.28 + shiftX2 + soldier2X_temp;  soldier2BulletY[3] = -2.36;
    soldier2BulletX[4] = 3.91 + shiftX2 + soldier2X_temp;  soldier2BulletY[4] = -2.36;
    soldier2BulletX[5] = 3.55 + shiftX2 + soldier2X_temp;  soldier2BulletY[5] = -2.36;

    soldier2BulletVisible = 0; // reset visibility counter
}
// start plane
if(key == 'p' && planeMoving==0) {
    planeMoving = 1;
    planeX = 10.0f;
}
if(key == 'o' && planeMoving) // drop bomb
{
    bombDropped = 1;
    //bombX = planeX + 4.95f;
    bombY = 1.2f;             // plane height (starting Y)
}

if (key == 'k')  // press 'f' to fire for left tank bomb
    {
        if(!bombShot)
        {
            bombShot = true;
            bombX = 6.45 + shiftX1;  // tank cannon X
            bombY = -1.90 + shiftY1; // tank cannon Y
            bombVX = 0.25f;           // horizontal speed
            bombVY = 0.3f;           // initial vertical speed
        }
    }




    glutPostRedisplay();
}

void update(int v)
{
    if(fire1) { bullet1X -= 0.1 * cos(rad); bullet1Y += 0.1 * sin(rad);
        if(bullet1X < 2.0){ fire1=0; blast1=1; blastTime1=0; } }
    if(blast1){ blastTime1++; if(blastTime1>10) blast1=0; }

    if(fire2) { bullet2X -= 0.1 * cos(rad); bullet2Y += 0.1 * sin(rad);
        if(bullet2X < 2.0){ fire2=0; blast2=1; blastTime2=0; } }
    if(blast2){ blastTime2++; if(blastTime2>10) blast2=0; }

    if(soldierFire)
    {
     for(int i=0;i<6;i++)
     {
        soldierBulletX[i] -= soldierBulletSpeed; // move right
     }
     soldierBulletVisible++;

     if(soldierBulletVisible > 10) // show for 10 frames
     {
        soldierFire = 0;
        soldierBulletVisible = 0;
     }
    }
    if(soldier2Fire)
{
    for(int i=0; i<6; i++)
    {
        soldier2BulletX[i] += soldier2BulletSpeed; // move left
    }
    soldier2BulletVisible++;

    if(soldier2BulletVisible > 10)
    {
        soldier2Fire = 0;
        soldier2BulletVisible = 0;
    }
}
//////// plane
if(planeMoving) {
    planeX -= planeSpeed;   // move right
    if(planeX < -18.0f) {    // off-screen
        planeMoving = 0;    // stop moving
         planeX = 10.0f; // reset to start
    }
}

if(bombDropped)
{
    bombY -= bombSpeed;  // move vertically down


    bombX = planeX + 4.95f;

    if(bombY < -2.2f)    // hit ground
    {
        bombDropped = 0;  // stop bomb falling
        bombBlast = 1;    // start explosion
        bombBlastTime = 0;
    }
}

// handle bomb explosion duration
if(bombBlast)
{
    bombBlastTime++;
    if(bombBlastTime > 2)
    {
        bombBlast = 0;
    }
}
////////  left tank
if(bombShot)
{
    bombX += bombVX;
    bombY += bombVY;
    bombVY -= gravity;

    if(bombY < -2.3f)       // hit ground
    {
        bombShot = false;

        // explosionX = bombX; explosionY = -2.3f;
    }
}





    glutPostRedisplay();
    glutTimerFunc(40, update, 0);
}



int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1400, 600);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("WAR SCENARIO");

    initGL();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(100, timer, 0);
    glutTimerFunc(50, update, 0);

    glutMainLoop();

    return 0;
}
